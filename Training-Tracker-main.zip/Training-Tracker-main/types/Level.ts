type Level = {
  id: number;
  level: string;
  time: string;
  Performance: string;
  P1: string;
  P2: string;
  P3: string;
  P4: string;
};

export type { Level };