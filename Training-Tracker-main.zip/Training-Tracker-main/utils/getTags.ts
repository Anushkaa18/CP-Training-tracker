const tags = [
  "Brute Force",
  "Number Theory",
  "Math",
  "Combinatorics",
  "Constructives",
  "Probabilities",
  "Graphs",
  "Sortings",
  "Bitmasks",
  "Data Structures",
  "Implementation",
  "Trees",
];

export default tags;
